/* Frontend controller: fetches JSON from Flask and draws charts with Chart.js. */
const $ = (id) => document.getElementById(id);
const chartInstances = {};
let modelPayload = null;
let allTransactions = [];

async function api(path, options = {}) {
  const response = await fetch(path, {
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options
  });
  if (response.status === 401) { window.location.href = "/login"; throw new Error("Please sign in again."); }
  const payload = await response.json();
  if (!response.ok) throw new Error(payload.error || "Request failed.");
  return payload;
}
function toast(message) {
  const el = $("toast"); el.textContent = message; el.classList.add("show");
  setTimeout(() => el.classList.remove("show"), 2600);
}
function number(n) { return Number(n || 0).toLocaleString("en-IN"); }
function makeChart(id, config) {
  if (chartInstances[id]) chartInstances[id].destroy();
  const ctx = $(id); if (ctx) chartInstances[id] = new Chart(ctx, config);
}
const chartOptions = {
  responsive: true, maintainAspectRatio: false,
  plugins: { legend: { labels: { usePointStyle: true, boxWidth: 7, font: { size: 10 } } } },
  scales: {
    x: { grid: { display: false }, ticks: { color: "#8791a8", font: { size: 9 } }, border: { display: false } },
    y: { beginAtZero: true, grid: { color: "#f0f2f8" }, ticks: { color: "#8791a8", font: { size: 9 } }, border: { display: false } }
  }
};
function drawOverview(data) {
  $("kpi-total").textContent = number(data.total_transactions);
  $("kpi-rate").textContent = `${data.fraud_rate}%`;
  $("kpi-blocked").textContent = number(data.fraud_blocked);
  $("kpi-fpr").textContent = `${data.false_positive_rate}%`;
  makeChart("timeChart", {type:"line",data:{labels:data.time_labels,datasets:[{label:"Fraud-labelled transactions",data:data.time_values,borderColor:"#5368ee",backgroundColor:"#5368ee18",fill:true,tension:.35,pointRadius:2,borderWidth:2}]},options:chartOptions});
  makeChart("merchantChart", {type:"bar",data:{labels:data.merchant_labels,datasets:[{label:"Fraud count",data:data.merchant_values,backgroundColor:["#5368ee","#7d8cff","#9ca8ff","#bac2ff","#6579ec","#c9ceff","#8595f4"],borderRadius:5,maxBarThickness:34}]},options:{...chartOptions,plugins:{legend:{display:false}}}});
}
function renderTable(id, columns, rows, formatter = (value) => value ?? "—") {
  const table = $(id);
  table.innerHTML = `<thead><tr>${columns.map(c=>`<th>${c.label}</th>`).join("")}</tr></thead><tbody>${
    rows.map(row=>`<tr>${columns.map(c=>`<td>${formatter(row[c.key], c.key, row)}</td>`).join("")}</tr>`).join("")
  }</tbody>`;
}
async function loadDataScreen() {
  const d = await api("/api/data");
  renderTable("dataset-table", d.columns.map(key=>({key,label:key.replaceAll("_"," ")})), d.rows,
    (v,key)=>key==="is_fraud" ? `<span class="status ${v ? "flagged":"approved"}">${v ? "Fraud":"Legitimate"}</span>` : (typeof v==="number" ? number(v) : v));
  $("preprocessing-list").innerHTML = d.preprocessing.map((x,i)=>`<div class="pipeline-item"><span class="step-no">${String(i+1).padStart(2,"0")}</span><div><strong>${x.step}</strong><p>${x.detail}</p></div></div>`).join("");
  $("feature-list").innerHTML = d.features.map(x=>`<div class="feature-card"><strong>${x.name}</strong><p>${x.detail}</p></div>`).join("");
  makeChart("balanceChart",{type:"bar",data:{labels:["Legitimate","Fraud"],datasets:[
    {label:"Before SMOTE",data:d.counts.before,backgroundColor:"#aeb8d5",borderRadius:5},
    {label:"After SMOTE",data:d.counts.after,backgroundColor:"#5368ee",borderRadius:5}
  ]},options:chartOptions});
}
function renderModelInspection(name) {
  if (!modelPayload || !name) return;
  const c = modelPayload.confusion[name];
  $("confusion-matrix").innerHTML = [
    ["True negative",c.tn],["False positive",c.fp],["False negative",c.fn],["True positive",c.tp]
  ].map(([label,value])=>`<div class="confusion-cell"><span>${label}</span><strong>${number(value)}</strong></div>`).join("");
  const curve = modelPayload.curves[name];
  makeChart("prChart",{type:"line",data:{labels:curve.recall,datasets:[{label:"Precision",data:curve.precision,borderColor:"#5368ee",pointRadius:0,borderWidth:2,tension:.15}]},options:{...chartOptions,scales:{...chartOptions.scales,x:{...chartOptions.scales.x,title:{display:true,text:"Recall",color:"#8791a8"}},y:{...chartOptions.scales.y,min:0,max:1,title:{display:true,text:"Precision",color:"#8791a8"}}}}});
}
async function loadModels() {
  modelPayload = await api("/api/models");
  renderTable("model-table",[
    {key:"model",label:"Model"},{key:"precision",label:"Precision"},{key:"recall",label:"Recall"},
    {key:"f1",label:"F1 score"},{key:"auc_pr",label:"AUC-PR"},{key:"latency_ms",label:"Latency / row (ms)"}
  ],modelPayload.results,(v,key)=>key==="model"?`<strong>${v}</strong>`:v);
  $("model-select").innerHTML = modelPayload.model_names.map(n=>`<option value="${n}">${n}</option>`).join("");
  const metrics = ["precision","recall","f1","auc_pr"];
  makeChart("metricsChart",{type:"bar",data:{labels:modelPayload.results.map(x=>x.model),datasets:metrics.map((m,i)=>({label:{"precision":"Precision","recall":"Recall","f1":"F1","auc_pr":"AUC-PR"}[m],data:modelPayload.results.map(x=>x[m]),backgroundColor:["#5368ee","#26b88a","#f0b34f","#8a78ee"][i],borderRadius:4}))},options:{...chartOptions,scales:{...chartOptions.scales,y:{...chartOptions.scales.y,min:0,max:1}}}});
  renderModelInspection($("model-select").value);
}
async function loadOptions() {
  const d = await api("/api/options");
  $("merchant_category").innerHTML = d.merchants.map(x=>`<option>${x}</option>`).join("");
  $("device_type").innerHTML = d.devices.map(x=>`<option>${x}</option>`).join("");
}
async function loadTransactions() {
  const d = await api("/api/transactions?limit=100");
  allTransactions = d.transactions;
  renderTransactions(allTransactions);
}
function renderTransactions(rows) {
  renderTable("transactions-table",[
    {key:"transaction_id",label:"Transaction ID"},{key:"amount",label:"Amount (₹)"},
    {key:"merchant_category",label:"Merchant"},{key:"device_type",label:"Device"},
    {key:"hour",label:"Hour"},{key:"location_risk",label:"Location risk"},
    {key:"txn_velocity_1h",label:"Velocity"},{key:"status",label:"Status"}
  ],rows,(v,key)=>key==="status"?`<span class="status ${v==="Flagged"?"flagged":"approved"}">${v}</span>`:key==="amount"?`₹${Number(v).toLocaleString("en-IN",{maximumFractionDigits:2})}`:v);
  $("transaction-count").textContent = `Showing ${rows.length} transaction records`;
}
function showScreen(name) {
  document.querySelectorAll(".screen").forEach(el=>el.classList.toggle("active",el.id===`screen-${name}`));
  document.querySelectorAll(".nav-item").forEach(el=>el.classList.toggle("active",el.dataset.screen===name));
  const titles={overview:"Overview dashboard",data:"Data & preprocessing",models:"Model comparison",scoring:"Real-time fraud scoring",transactions:"Transaction explorer"};
  $("page-title").textContent=titles[name]||"Dashboard";
  if(name==="data") loadDataScreen().catch(e=>toast(e.message));
  if(name==="models") loadModels().catch(e=>toast(e.message));
  if(name==="transactions") loadTransactions().catch(e=>toast(e.message));
}
document.querySelectorAll(".nav-item").forEach(btn=>btn.addEventListener("click",()=>showScreen(btn.dataset.screen)));
$("model-select").addEventListener("change",()=>renderModelInspection($("model-select").value));
$("score-form").addEventListener("submit",async event=>{
  event.preventDefault(); $("score-error").textContent="";
  const form=new FormData(event.currentTarget), payload=Object.fromEntries(form.entries());
  ["amount","location_risk","deviation_from_avg"].forEach(k=>payload[k]=Number(payload[k]));
  ["hour","txn_velocity_1h","account_age_days"].forEach(k=>payload[k]=parseInt(payload[k],10));
  try {
    const result=await api("/api/score",{method:"POST",body:JSON.stringify(payload)});
    $("risk-number").textContent=result.risk_score;
    $("risk-gauge").style.setProperty("--score",`${result.risk_score*3.6}deg`);
    $("risk-level").className=`risk-badge ${result.risk_level.toLowerCase()}`;
    $("risk-level").textContent=`${result.risk_level} risk`;
    $("risk-decision").textContent=result.decision;
    $("risk-detail").textContent=`Estimated fraud probability: ${result.risk_score}%`;
    $("model-used").textContent=result.model_used;
    toast("Transaction scored successfully");
  } catch(e) { $("score-error").textContent=e.message; }
});
$("refresh-transactions").addEventListener("click",()=>loadTransactions().then(()=>toast("Transaction list refreshed")).catch(e=>toast(e.message)));
$("transaction-search").addEventListener("input",()=>{
  const q=$("transaction-search").value.toLowerCase();
  renderTransactions(allTransactions.filter(x=>[x.transaction_id,x.merchant_category,x.status,x.device_type].some(v=>String(v).toLowerCase().includes(q))));
});
(async function init(){
  try {
    const overview=await api("/api/overview"); drawOverview(overview);
    await loadOptions();
  } catch(e) { toast(e.message); }
})();
