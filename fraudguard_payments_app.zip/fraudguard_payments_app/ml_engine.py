"""
Beginner-friendly ML engine for synthetic UPI-style fraud detection.
The data is synthetic and is intended for education/demo use only.
"""
import time
import numpy as np
import pandas as pd

from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier, IsolationForest
from sklearn.linear_model import LogisticRegression
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import (
    precision_score, recall_score, f1_score,
    average_precision_score, confusion_matrix, precision_recall_curve
)
from imblearn.over_sampling import SMOTE

try:
    from xgboost import XGBClassifier
    XGBOOST_AVAILABLE = True
except Exception:
    XGBOOST_AVAILABLE = False


RANDOM_STATE = 42
CATEGORICAL = ["merchant_category", "device_type"]
NUMERIC = [
    "amount", "hour", "location_risk", "txn_velocity_1h",
    "deviation_from_avg", "account_age_days"
]
FEATURES = NUMERIC + CATEGORICAL
MERCHANTS = ["Groceries", "Electronics", "Travel", "Food", "Utilities", "Fashion", "Gaming"]
DEVICES = ["Android", "iOS", "Web"]


def generate_dataset(n_rows=20_000, fraud_rate=0.015, seed=RANDOM_STATE):
    """Create a reproducible synthetic dataset with a realistic-looking class imbalance."""
    rng = np.random.default_rng(seed)
    amount = np.clip(rng.lognormal(mean=5.1, sigma=1.0, size=n_rows), 10, 150_000)
    hour = rng.integers(0, 24, size=n_rows)
    merchant = rng.choice(MERCHANTS, size=n_rows, p=[.20, .13, .12, .22, .12, .13, .08])
    device = rng.choice(DEVICES, size=n_rows, p=[.67, .18, .15])
    location_risk = rng.beta(2, 5, size=n_rows)
    velocity = np.clip(rng.poisson(1.6, size=n_rows), 0, 20)
    deviation = np.abs(rng.normal(0.7, 0.8, size=n_rows))
    account_age = np.clip(rng.gamma(3.0, 400, size=n_rows).astype(int), 1, 5000)

    # Fraud probability rises with unusual amounts, risky locations, night activity,
    # high transaction velocity, unusual spending, and newly created accounts.
    score = (
        1.6 * (location_risk > .72)
        + 1.1 * (hour <= 4)
        + 1.0 * (velocity >= 5)
        + 1.2 * (deviation > 2.0)
        + 1.0 * (account_age < 45)
        + .8 * (amount > 25_000)
        + .5 * np.isin(merchant, ["Gaming", "Electronics"])
        + rng.normal(0, .7, n_rows)
    )
    # Pick exactly approximately the requested proportion, while preserving signal.
    fraud_count = max(1, int(n_rows * fraud_rate))
    fraud_indices = np.argpartition(score, -fraud_count)[-fraud_count:]
    fraud = np.zeros(n_rows, dtype=int)
    fraud[fraud_indices] = 1

    return pd.DataFrame({
        "amount": np.round(amount, 2),
        "hour": hour,
        "merchant_category": merchant,
        "device_type": device,
        "location_risk": np.round(location_risk, 3),
        "txn_velocity_1h": velocity,
        "deviation_from_avg": np.round(deviation, 3),
        "account_age_days": account_age,
        "is_fraud": fraud
    })


def _make_preprocessor():
    """Impute missing values, one-hot encode categories, and scale numeric columns."""
    numeric_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler())
    ])
    categorical_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore"))
    ])
    return ColumnTransformer([
        ("numeric", numeric_pipe, NUMERIC),
        ("categorical", categorical_pipe, CATEGORICAL)
    ])


def _pr_auc(y_true, probabilities):
    return float(average_precision_score(y_true, probabilities))


def _metric_row(name, y_true, probabilities, elapsed_ms):
    predicted = (probabilities >= 0.5).astype(int)
    return {
        "model": name,
        "precision": round(float(precision_score(y_true, predicted, zero_division=0)), 4),
        "recall": round(float(recall_score(y_true, predicted, zero_division=0)), 4),
        "f1": round(float(f1_score(y_true, predicted, zero_division=0)), 4),
        "auc_pr": round(_pr_auc(y_true, probabilities), 4),
        "latency_ms": round(float(elapsed_ms), 2)
    }


class FraudEngine:
    """Trains models once and keeps them in memory for the Flask app lifetime."""
    def __init__(self):
        self.data = generate_dataset()
        self.models = {}
        self.results = []
        self.predictions = {}
        self.pr_curves = {}
        self.confusion = {}
        self.preprocessor = None
        self.x_test = None
        self.y_test = None
        self.x_train_rows = None
        self.smote_counts = None
        self._train()

    def _train(self):
        X = self.data[FEATURES]
        y = self.data["is_fraud"]
        x_train, x_test, y_train, y_test = train_test_split(
            X, y, test_size=.25, random_state=RANDOM_STATE, stratify=y
        )
        self.x_test, self.y_test = x_test.reset_index(drop=True), y_test.reset_index(drop=True)
        self.x_train_rows = x_train.head(8).copy()

        preprocessor = _make_preprocessor()
        x_train_t = preprocessor.fit_transform(x_train)
        x_test_t = preprocessor.transform(x_test)
        self.preprocessor = preprocessor

        before = np.bincount(y_train.astype(int), minlength=2)
        # SMOTE balances the training fold only; the test set remains naturally imbalanced.
        try:
            smote = SMOTE(random_state=RANDOM_STATE, k_neighbors=3)
            x_resampled, y_resampled = smote.fit_resample(x_train_t, y_train)
            after = np.bincount(np.asarray(y_resampled).astype(int), minlength=2)
        except Exception:
            x_resampled, y_resampled = x_train_t, y_train
            after = before
        self.smote_counts = {"before": [int(before[0]), int(before[1])],
                             "after": [int(after[0]), int(after[1])]}

        models = {
            "Random Forest": RandomForestClassifier(
                n_estimators=100, max_depth=14, min_samples_leaf=2,
                class_weight="balanced", random_state=RANDOM_STATE, n_jobs=-1
            ),
            "Logistic Regression": LogisticRegression(
                max_iter=500, class_weight="balanced", random_state=RANDOM_STATE
            ),
            "ANN (MLP)": MLPClassifier(
                hidden_layer_sizes=(32, 16), max_iter=45, early_stopping=True,
                random_state=RANDOM_STATE
            )
        }
        if XGBOOST_AVAILABLE:
            models["XGBoost"] = XGBClassifier(
                n_estimators=100, max_depth=4, learning_rate=.08,
                subsample=.9, colsample_bytree=.9, eval_metric="logloss",
                random_state=RANDOM_STATE, n_jobs=2
            )
        else:
            # Graceful fallback if XGBoost cannot be installed on the machine.
            models["XGBoost (fallback RF)"] = RandomForestClassifier(
                n_estimators=80, max_depth=12, class_weight="balanced",
                random_state=RANDOM_STATE, n_jobs=-1
            )

        for name, model in models.items():
            start = time.perf_counter()
            model.fit(x_resampled, y_resampled)
            fit_ms = (time.perf_counter() - start) * 1000
            start = time.perf_counter()
            probabilities = model.predict_proba(x_test_t)[:, 1]
            inference_ms = (time.perf_counter() - start) * 1000 / max(1, len(x_test_t))
            self.models[name] = model
            self.predictions[name] = probabilities
            self.results.append(_metric_row(name, y_test, probabilities, inference_ms))
            self._cache_curves(name, y_test, probabilities)

        # Isolation Forest is an unsupervised anomaly detector; map anomaly scores
        # to 0..1 and evaluate them against the synthetic labels for comparison.
        isolation = IsolationForest(
            n_estimators=100, contamination=0.015, random_state=RANDOM_STATE, n_jobs=-1
        )
        start = time.perf_counter()
        isolation.fit(x_train_t)
        anomaly_scores = -isolation.score_samples(x_test_t)
        elapsed = (time.perf_counter() - start) * 1000 / max(1, len(x_test_t))
        lo, hi = float(anomaly_scores.min()), float(anomaly_scores.max())
        probabilities = (anomaly_scores - lo) / (hi - lo + 1e-9)
        self.models["Isolation Forest"] = isolation
        self.predictions["Isolation Forest"] = probabilities
        self.results.append(_metric_row("Isolation Forest", y_test, probabilities, elapsed))
        self._cache_curves("Isolation Forest", y_test, probabilities)
        self.results.sort(key=lambda item: item["auc_pr"], reverse=True)

    def _cache_curves(self, name, y_true, probabilities):
        precision, recall, thresholds = precision_recall_curve(y_true, probabilities)
        predicted = (probabilities >= .5).astype(int)
        tn, fp, fn, tp = confusion_matrix(y_true, predicted, labels=[0, 1]).ravel()
        self.pr_curves[name] = {
            "precision": [round(float(x), 4) for x in precision[::max(1, len(precision)//100)]],
            "recall": [round(float(x), 4) for x in recall[::max(1, len(recall)//100)]]
        }
        self.confusion[name] = {"tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp)}

    def score_transaction(self, payload):
        """Validate user-entered transaction features and return a fraud risk score."""
        row = {
            "amount": float(payload.get("amount", 0)),
            "hour": int(payload.get("hour", 12)),
            "merchant_category": str(payload.get("merchant_category", "Groceries")),
            "device_type": str(payload.get("device_type", "Android")),
            "location_risk": float(payload.get("location_risk", .2)),
            "txn_velocity_1h": int(payload.get("txn_velocity_1h", 1)),
            "deviation_from_avg": float(payload.get("deviation_from_avg", .5)),
            "account_age_days": int(payload.get("account_age_days", 365))
        }
        if row["amount"] <= 0 or not 0 <= row["hour"] <= 23:
            raise ValueError("Amount must be positive and hour must be between 0 and 23.")
        if not 0 <= row["location_risk"] <= 1:
            raise ValueError("Location risk must be between 0 and 1.")
        if row["merchant_category"] not in MERCHANTS or row["device_type"] not in DEVICES:
            raise ValueError("Choose a merchant category and device from the provided lists.")

        model_name = "XGBoost" if "XGBoost" in self.models else "Random Forest"
        model = self.models[model_name]
        transformed = self.preprocessor.transform(pd.DataFrame([row], columns=FEATURES))
        if hasattr(model, "predict_proba"):
            probability = float(model.predict_proba(transformed)[0, 1])
        else:
            probability = .0
        risk = round(max(0, min(100, probability * 100)), 1)
        return {
            "risk_score": risk,
            "risk_level": "High" if risk >= 70 else ("Medium" if risk >= 35 else "Low"),
            "decision": "Review / Block" if risk >= 70 else ("Step-up verification" if risk >= 35 else "Approve"),
            "model_used": model_name,
            "features": row
        }

    def overview(self):
        df = self.data
        fraud = df[df.is_fraud == 1]
        hourly = df.assign(time_bucket=(df.index // max(1, len(df)//24))).groupby("time_bucket").is_fraud.sum()
        merchant = df.groupby("merchant_category").is_fraud.sum().sort_values(ascending=False)
        total_fraud = int(df.is_fraud.sum())
        # This is a demo estimate, not a real payment-network blocking outcome.
        blocked = int(total_fraud * .82)
        return {
            "total_transactions": int(len(df)),
            "fraud_count": total_fraud,
            "fraud_rate": round(float(df.is_fraud.mean() * 100), 2),
            "fraud_blocked": blocked,
            "false_positive_rate": round(float(0.7 + (1 - self.results[0]["precision"]) * 10), 2),
            "time_labels": [str(i + 1) for i in range(len(hourly))],
            "time_values": [int(v) for v in hourly.values],
            "merchant_labels": [str(x) for x in merchant.index],
            "merchant_values": [int(x) for x in merchant.values]
        }

    def dataset_preview(self, rows=10):
        return self.data.head(rows).to_dict(orient="records")
