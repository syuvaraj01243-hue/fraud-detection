"""Flask entry point for the FraudGuard AI demonstration app."""
import os
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from ml_engine import FraudEngine, MERCHANTS, DEVICES

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "change-this-demo-secret-before-deployment")
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"

# Demo credentials: username=admin, password=fraud@123.
# Only a hash is kept in memory; the plain password is not stored.
DEMO_USERNAME = "admin"
DEMO_PASSWORD_HASH = generate_password_hash("fraud@123")

# Training happens once at startup and cached model metrics are reused by API routes.
engine = FraudEngine()


def login_required(view):
    """Protect a page or API route unless a user has an authenticated session."""
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("authenticated"):
            if request.path.startswith("/api/"):
                return jsonify({"error": "Please sign in first."}), 401
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


@app.route("/", methods=["GET"])
def home():
    return redirect(url_for("dashboard") if session.get("authenticated") else url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if username == DEMO_USERNAME and check_password_hash(DEMO_PASSWORD_HASH, password):
            session.clear()
            session["authenticated"] = True
            session["username"] = username
            return redirect(url_for("dashboard"))
        error = "Incorrect username or password. Please try again."
    return render_template("login.html", error=error)


@app.route("/logout", methods=["POST", "GET"])
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/dashboard")
@login_required
def dashboard():
    return render_template("dashboard.html", username=session.get("username", "admin"))


@app.route("/api/overview")
@login_required
def api_overview():
    return jsonify(engine.overview())


@app.route("/api/data")
@login_required
def api_data():
    return jsonify({
        "rows": engine.dataset_preview(12),
        "columns": list(engine.data.columns),
        "counts": engine.smote_counts,
        "preprocessing": [
            {"step": "Numeric missing values", "detail": "Median imputation"},
            {"step": "Categorical missing values", "detail": "Most-frequent imputation"},
            {"step": "Categorical encoding", "detail": "One-hot encoding; unseen categories ignored"},
            {"step": "Numeric scaling", "detail": "StandardScaler fitted on training data only"},
            {"step": "Class balancing", "detail": "SMOTE applied to training fold only"}
        ],
        "features": [
            {"name": "txn_velocity_1h", "detail": "Number of transactions in the last hour"},
            {"name": "deviation_from_avg", "detail": "Absolute deviation from normal spending"},
            {"name": "location_risk", "detail": "Synthetic risk score from 0 to 1"},
            {"name": "account_age_days", "detail": "Account tenure in days"}
        ]
    })


@app.route("/api/models")
@login_required
def api_models():
    return jsonify({
        "results": engine.results,
        "model_names": [row["model"] for row in engine.results],
        "curves": engine.pr_curves,
        "confusion": engine.confusion
    })


@app.route("/api/score", methods=["POST"])
@login_required
def api_score():
    payload = request.get_json(silent=True) or {}
    try:
        return jsonify(engine.score_transaction(payload))
    except (ValueError, TypeError) as exc:
        return jsonify({"error": str(exc)}), 400


@app.route("/api/transactions")
@login_required
def api_transactions():
    """A searchable synthetic transaction feed for the fifth screen."""
    limit = min(max(request.args.get("limit", default=50, type=int), 1), 200)
    df = engine.data.tail(limit).copy()
    df["transaction_id"] = [f"UPI-{i:06d}" for i in range(len(engine.data)-len(df)+1, len(engine.data)+1)]
    df["status"] = df["is_fraud"].map({1: "Flagged", 0: "Approved"})
    return jsonify({"transactions": df.to_dict(orient="records")})


@app.route("/api/options")
@login_required
def api_options():
    return jsonify({"merchants": MERCHANTS, "devices": DEVICES})


if __name__ == "__main__":
    # Debug is off by default to avoid running the training code twice.
    app.run(host="127.0.0.1", port=5000, debug=False)
